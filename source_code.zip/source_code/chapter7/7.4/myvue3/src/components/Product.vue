<template>
    <div id="product"></div>
</template>

<script>
import { start } from 'qiankun';
export default {
    mounted() {
        if (!window.qiankunStarted) {
            window.qiankunStarted = true;
            start({//乾坤配置  https://qiankun.umijs.org/zh/api
                // 开启shadow dom沙箱隔离
                sandbox: { strictStyleIsolation: true }
            })
        }
    }
}
</script>
