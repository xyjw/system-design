import {createApp} from 'vue'
import App from './App.vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import { createRouter, createWebHistory } from 'vue-router'
import Product from './components/Product.vue'
import Signin from './components/Signin.vue'
import {registerMicroApps, start} from 'qiankun'

// 定义路由，路由设置:url*是运行微应用能自行添加多条路由地址
const routes = [
  { path: '/', component: Signin },
  { path: '/product/:url*', component: Product },
]

// 创建路由对象
const router = createRouter({
  // 设置历史记录模式
  history: createWebHistory(),
  // routes: routes的缩写
  routes,
})

const app = createApp(App)
// 将路由对象绑定到Vue对象
app.use(router)
// 将vue-axios与axios关联并绑定到Vue对象
app.use(VueAxios,axios)
// 挂载使用Vue对象
app.mount('#app')

// 在主应用中注册微应用
registerMicroApps([
    {
        name: 'product', // 微应用的名称
        entry: 'http://localhost:8008', // 微应用的运行地址
        container: '#product', // 微应用的HTML节点
        activeRule: '/product', // 微应用的激活规则
    }
])
start()

