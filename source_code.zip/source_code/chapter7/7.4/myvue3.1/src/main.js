import './public-path'
import {createApp} from 'vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import {createRouter, createWebHistory} from 'vue-router'
import App from './App.vue'
import Product from './components/Product.vue'

// 定义路由
const routes = [
    // 可自定定义路由，所有路由前缀皆为/product/xxx
    {path: '/', component: Product},
    {path: '/b', component: Product},
]

// 创建路由对象
const router = createRouter({
    // 设置历史记录模式，history必须设置/product
    // 对应主应用registerMicroApps的activeRule
    history: createWebHistory('/product'),
    // routes: routes的缩写
    routes,
})

function render(props = {}) {
    const {container} = props
    const instance = createApp(App)
    instance.use(router)
    // 将vue-axios与axios关联并绑定到Vue对象
    instance.use(VueAxios, axios)
    instance.mount(container ? container.querySelector('#app') : '#app')
}

if (!window.__POWERED_BY_QIANKUN__) {
    render()
}

// 生命周期 - 挂载前，在这里由主应用传过来的参数
export async function bootstrap() {
    console.log("VueMicroApp bootstraped");
}

// 生命周期 - 挂载后
export async function mount(props) {
    console.log("VueMicroApp mount", props);
    render(props);
}

// 生命周期 - 解除挂载
export async function unmount() {
    console.log("VueMicroApp unmount");
}
