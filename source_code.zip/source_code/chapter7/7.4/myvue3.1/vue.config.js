const { name } = require('./package.json')
const path = require('path');

function resolve(dir) {
  return path.join(__dirname, dir);
}

module.exports = {
  devServer: {
    port: 8008,
    headers: {
      'Access-Control-Allow-Origin': '*'
    }
  },
  configureWebpack: {
    resolve: {
      alias: {
        '@': resolve('src'),
      },
    },
    output: {
      library: `${name}-[name]`,
      // 把微应用打包成umd库格式
      // 当libraryTarget设置为umd后，library所有的模块设为可运行方式，
      // 主应用就可以获取到微应用的生命周期钩子函数
      libraryTarget: 'umd',
      jsonpFunction: `webpackJsonp_${name}`
    }
  }
}
