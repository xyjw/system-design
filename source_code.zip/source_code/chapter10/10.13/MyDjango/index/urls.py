from django.urls import path
from .views import *

urlpatterns = [
    path('modify/product/', modifyProductView, name='modifyProduct'),
    path('update/product/', updateProductView, name='updateProduct'),
]
