from django.http import JsonResponse
from .models import *
from django.db import transaction
import time


def modifyProductView(request):
    result = {'result': 'done'}
    if request.method == 'GET':
        name = request.GET.get('name', '')
        # 方法一
        p1 = Product.objects.filter(name=name, status=1).first()
        p2 = Product.objects.filter(name=name, status=1).first()
        p1.quantity = 10
        p2.quantity = 20
        p1.save()
        p2.save()

        # 方法二
        # 查询当前最新的版本标识字段
        p3 = Product.objects.filter(name=name, status=1).first()
        version = p3.version
        # 将查询所得版本标识字段作为筛选条件再执行数据更新操作
        f = dict(name=name, status=1, version=version)
        # 使用update()更新数据需要自行更新版本标识字段
        u = dict(quantity=66, version=int(time.time()*1000000))
        Product.objects.filter(**f).update(**u)
    return JsonResponse(result, safe=False)


def updateProductView(request):
    result = {'result': 'done'}
    if request.method == 'GET':
        name = request.GET.get('name', '')
        product = Product.objects.select_for_update().filter(status=1)
        if name:
            product = product.filter(name=name)
        # 可以根据自身需要结合事务一并使用
        with transaction.atomic():
            product.update(quantity=66)
    return JsonResponse(result, safe=False)
