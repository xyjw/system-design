import consul
import json
# 启动Consul
# consul agent -server -ui -bootstrap-expect=1 -data-dir=D:\consul -node=agent-one -advertise=127.0.0.1 -bind=0.0.0.0 -client=0.0.0.0

# 连接Consul
c = consul.Consul(host='127.0.0.1', port=8500)
# 获取Consul的KV存储服务（即配置中心功能）对象
kv = c.kv

# 读取操作
# 获取所有key（配置名称）
_, data = kv.get(key='', keys=True)
# 输出配置内容
print(f'获取所有key（配置名称）：{"、".join(data)}')

# 读取配置中心的某条配置信息
_, data = kv.get('person')
# 输出配置内容
j = json.loads(data['Value'])
print(f"输出person的配置内容：{j}")

# 新增或修改操作
# key（配置名称）已存在则执行修改
# key（配置名称）不存在则执行新增
# 修改配置内容
j['name'] = 'Lily'
kv.put('person', json.dumps(j))
# 新增配置内容
kv.put('city', json.dumps({'name': 'shenzheng'}))

# 删除操作
# 通过key（配置名称）实现删除操作
# kv.delete('person')
