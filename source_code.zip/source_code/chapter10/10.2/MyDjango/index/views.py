import time
from django.http import JsonResponse
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import jwt


@csrf_exempt
def loginView(request):
    res = {'result': False, 'token': ''}
    if request.method == 'POST':
        u = request.POST.get('username', '')
        p = request.POST.get('password', '')
        if User.objects.filter(username=u):
            user = authenticate(username=u, password=p)
            if user:
                if user.is_active:
                    d = dict(username=user.username,
                             exp=int(time.time()) + settings.TOKEN_EXP,
                             iat=int(time.time()))
                    key = settings.SECRET_KEY
                    try:
                        # 1.17版本之前需要使用decode()转字符串
                        j = jwt.encode(d, key, algorithm="HS256").decode('utf-8')
                    except:
                        # 新版本直接返回字符串格式
                        j = jwt.encode(d, key, algorithm="HS256")
                    res['result'] = True
                    res['token'] = j
    return JsonResponse(res)


def productView(request):
    if request.method == 'GET':
        q = request.GET.get('q', '')
        data = Product.objects.filter(status=1)
        if q:
            data = Product.objects.filter(name__icontains=q)
        result = []
        for i in data.all():
            value = {'name': i.name,
                     'quantity': i.quantity,
                     'kinds': i.kinds}
            result.append(value)
        return JsonResponse(result, safe=False)
