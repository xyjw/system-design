from django.conf import settings
from django.utils.deprecation import MiddlewareMixin
from django.http import JsonResponse
import jwt

class MyAuthenticationMiddleware(MiddlewareMixin):
    def process_request(self, request):
        url_path = request.path
        check = True
        if url_path == '/':
            check = False
        if check:
            key = settings.SECRET_KEY
            token = request.headers.get('Token')
            d = {"result": False, "msg": "please login"}
            if token:
                # 检验JWT有效期
                try:
                    jwt.decode(token, key, algorithms="HS256")
                except Exception as e:
                    if 'Signature has expired' in str(e):
                        return JsonResponse(d)
            else:
                print(f'token is {token}')
                return JsonResponse(d)
