from kafka import KafkaConsumer, KafkaProducer
import json
from django.core.management.base import BaseCommand
from index.models import Product

def send_order(data):
    '''
    订单生产者，向订单应用发送商品信息
    :param data:
    :return:
    '''
    producer = KafkaProducer(bootstrap_servers=['127.0.0.1:9092'])
    # 设置Kafka的主题
    topic = 'order'
    # 向主题order发送数据
    data = json.dumps(data, ensure_ascii=True).encode('utf-8')
    producer.send(topic=topic, value=data, partition=0)
    producer.close()

class Command(BaseCommand):
    def handle(self, *args, **options):
        '''
        商品消费者
        :return:
        '''
        bs = ['127.0.0.1:9092']
        consumer = KafkaConsumer('product',
                                 bootstrap_servers=bs,
                                 group_id='product')
        for i in consumer:
            status = json.loads(i.value).get('status')
            id = json.loads(i.value).get('id')
            name = json.loads(i.value).get('name')
            quantity = json.loads(i.value).get('quantity')
            if name:
                p = Product.objects.filter(name=name).first()
                # 库存量与购买量对比
                if p.quantity >= int(quantity):
                    p.quantity -= int(quantity)
                    p.save()
                    if not status:
                        # 调用生产者发送数据
                        send_order({'id': id, 'result': True})
                else:
                    # 调用生产者发送数据
                    send_order({'id': id, 'result': False})
