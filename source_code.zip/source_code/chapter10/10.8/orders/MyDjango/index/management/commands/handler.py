from kafka import KafkaConsumer, KafkaProducer
import json
from django.core.management.base import BaseCommand
from index.models import Order

def send_product(data):
    '''
    商品生产者，向商品应用发送订单信息
    :param data:
    :return:
    '''
    producer = KafkaProducer(bootstrap_servers=['127.0.0.1:9092'])
    # 设置Kafka的主题
    topic = 'product'
    # 向主题product发送数据
    data = json.dumps(data, ensure_ascii=True).encode('utf-8')
    producer.send(topic=topic, value=data, partition=0)
    producer.close()

class Command(BaseCommand):
    def handle(self, *args, **options):
        '''
        订单消费者
        :return:
        '''
        # 连接Kafka
        bs = ['127.0.0.1:9092']
        consumer = KafkaConsumer('order',
                                 bootstrap_servers=bs,
                                 group_id='order')
        # 从主题order获取数据进行消费
        for i in consumer:
            id = json.loads(i.value).get('id')
            result = json.loads(i.value).get('result')
            print(id)
            if result:
                order = Order.objects.get(id=id)
                order.status = 1
                order.save()
            else:
                Order.objects.filter(id=id).delete()
