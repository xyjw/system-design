from django.http import JsonResponse
from .management.commands.handler import send_product
from .models import *
from django.forms.models import model_to_dict

def orderView(request):
    name = request.GET.get('name', '')
    quantity = request.GET.get('quantity', 0)
    if name:
        order = Order.objects.create(name=name, quantity=quantity)
        send_product(model_to_dict(order))
    return JsonResponse({'res': 'done'}, safe=False)
