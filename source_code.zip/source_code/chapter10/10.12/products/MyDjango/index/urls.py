from django.urls import path
from .views import *

urlpatterns = [
    path('ProductSaga/', ProductSagaView, name='ProductSaga'),
    path('ProductCompensate/', ProductCompensateView, name='ProductCompensate'),
]
