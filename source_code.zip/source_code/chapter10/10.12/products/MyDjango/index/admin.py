from django.contrib import admin
from .models import Product

admin.site.site_title = '产品查询管理平台'
admin.site.site_header = '产品查询管理平台'
admin.sites.index_title = '产品查询管理平台'

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = [x for x in Product._meta._forward_fields_map.keys()]
    search_fields = ['id', 'name']
    list_filter = ['kinds', 'status']
