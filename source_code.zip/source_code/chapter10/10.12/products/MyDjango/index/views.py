from django.http import JsonResponse
from dtmcli import barrier
from django.db import connection
from django.views.decorators.csrf import csrf_exempt
import json
from .models import *

def barrier_from_req(request):
    '''
    获取请求参数
    :param request:
    :return:
    '''
    tt = request.GET.get("trans_type")
    gd = request.GET.get("gid")
    bi = request.GET.get("branch_id")
    op = request.GET.get("op")
    return barrier.BranchBarrier(tt, gd, bi, op)

@csrf_exempt
def ProductSagaView(request):
    '''
    商品库存处理服务
    :param request:
    :return:
    '''
    jsonStr = json.loads(request.body)
    name = jsonStr.get('name', '')
    quantity = jsonStr.get('quantity', '0')
    # connection.cursor().cursor.cursor是使用Django的数据库连接对象
    with barrier.AutoCursor(connection.cursor().cursor.cursor) as cursor:
        def orderCallback(c):
            p = Product.objects.filter(name=name).first()
            if p:
                if p.quantity < int(quantity):
                   raise Exception("error")
                else:
                   p.quantity = p.quantity - int(quantity)
                   p.save()
            else:
                raise Exception("error")
        barrier_from_req(request).call(cursor, orderCallback)
    return JsonResponse({'res': 'done'}, safe=False)

@csrf_exempt
def ProductCompensateView(request):
    '''
    商品库存处理补偿服务，用于回滚商品库存处理服务
    :param request:
    :return:
    '''
    # connection.cursor().cursor.cursor是使用Django的数据库连接对象
    with barrier.AutoCursor(connection.cursor().cursor.cursor) as cursor:
        def orderCallback(c):
            pass
        barrier_from_req(request).call(cursor, orderCallback)
    return JsonResponse({'res': 'done'}, safe=False)
