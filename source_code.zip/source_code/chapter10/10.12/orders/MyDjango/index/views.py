from django.http import JsonResponse
from .models import *
from dtmcli import saga, barrier
from dtmcli import utils
from django.conf import settings
from django.db import connection
from django.views.decorators.csrf import csrf_exempt
import json

def barrier_from_req(request):
    '''
    获取请求参数
    :param request:
    :return:
    '''
    tt = request.GET.get("trans_type")
    gd = request.GET.get("gid")
    bi = request.GET.get("branch_id")
    op = request.GET.get("op")
    return barrier.BranchBarrier(tt, gd, bi, op)

def orderView(request):
    '''
    订单创建接口
    :param request:
    :return:
    '''
    name = request.GET.get('name', '')
    quantity = request.GET.get('quantity', 0)
    req = dict(name=name, quantity=quantity)
    if name:
        # 查询模型Order最后一条数据，计算新增数据的主键ID
        order = Order.objects.order_by('-id').first()
        req['id'] = order.id + 1 if order else 1
        # 使用SAGA模式
        s = saga.Saga(settings.DTM, utils.gen_gid(settings.DTM))
        s.add(req, f'http://127.0.0.1:8000/OrderSaga/',
              f'http://127.0.0.1:8000/OrderCompensate/')
        s.add(req, 'http://127.0.0.1:8001/ProductSaga/',
              'http://127.0.0.1:8001/ProductCompensate/')
        s.submit()
    return JsonResponse({'res': 'done'}, safe=False)

@csrf_exempt
def OrderSagaView(request):
    '''
    订单创建服务，执行订单创建业务
    :param request:
    :return:
    '''
    jsonStr = json.loads(request.body)
    jsonStr['status'] = 0
    # connection.cursor().cursor.cursor是使用Django的数据库连接对象
    with barrier.AutoCursor(connection.cursor().cursor.cursor) as cursor:
        def orderCallback(c):
            try:
                Order.objects.create(**jsonStr)
            except:
                raise Exception("error")
        barrier_from_req(request).call(cursor, orderCallback)
    return JsonResponse({'res': 'done'}, safe=False)

@csrf_exempt
def OrderCompensateView(request):
    '''
    订单创建补偿服务，用于回滚订单创建服务
    :param request:
    :return:
    '''
    jsonStr = json.loads(request.body)
    id = jsonStr.get('id', '')
    # connection.cursor().cursor.cursor是使用Django的数据库连接对象
    with barrier.AutoCursor(connection.cursor().cursor.cursor) as cursor:
        def orderCallback(c):
            try:
                Order.objects.filter(id=id).delete()
            except:
                raise Exception("error")
        barrier_from_req(request).call(cursor, orderCallback)
    return JsonResponse({'res': 'done'}, safe=False)
