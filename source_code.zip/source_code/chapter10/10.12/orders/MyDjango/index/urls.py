from django.urls import path
from .views import *

urlpatterns = [
    path('order.html', orderView, name='order'),
    path('OrderSaga/', OrderSagaView, name='OrderSaga'),
    path('OrderCompensate/', OrderCompensateView, name='OrderCompensate'),
]
