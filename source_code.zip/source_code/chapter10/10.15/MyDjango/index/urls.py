from django.urls import path
from .views import *

urlpatterns = [
    path('add/product/sf/', createProductSfView, name='createProductSf'),
    path('add/product/rd/', createProductRdView, name='createProductRd'),
]
