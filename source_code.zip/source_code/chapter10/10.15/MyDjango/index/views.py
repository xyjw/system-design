from django.http import JsonResponse
from toollib.redis_cli import RedisCli
from .models import *
from toollib.guid import SnowFlake, RedisUid

def createProductSfView(request):
    result = {'result': 'done'}
    if request.method == 'GET':
        name = request.GET.get('name', '')
        quantity = request.GET.get('quantity', '10')
        d = dict(name=name, quantity=quantity, kinds=name)
        # 创建分布式ID
        # SnowFlake实例化
        # 参数说明查看源码文件Lib\site-packages\toollib\guid.py
        sf = SnowFlake(worker_id=1, datacenter_id=1)
        d['id'] = sf.gen_uid()
        print(f"分布式ID为：{d['id']}")
        Product.objects.create(**d)
    return JsonResponse(result, safe=False)

def createProductRdView(request):
    result = {'result': 'done'}
    if request.method == 'GET':
        name = request.GET.get('name', '')
        quantity = request.GET.get('quantity', '10')
        d = dict(name=name, quantity=quantity, kinds=name)
        # 创建分布式ID
        # RedisCli连接Redis
        redis_cli = RedisCli(host='127.0.0.1')
        # RedisUid是实例化Redis对象
        # 参数说明查看源码文件Lib\site-packages\toollib\guid.py
        ruid = RedisUid(redis_cli, seq_name='product')
        d['id'] = ruid.gen_uid()
        print(f"分布式ID为：{d['id']}")
        Product.objects.create(**d)
    return JsonResponse(result, safe=False)
