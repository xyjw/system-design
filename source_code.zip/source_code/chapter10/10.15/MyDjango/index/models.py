from django.db import models

STATUS = (
    (0, 0),
    (1, 1)
)

class Product(models.Model):
    id = models.BigIntegerField(primary_key=True)
    name = models.CharField('名称', max_length=50)
    quantity = models.IntegerField('数量', default=1)
    kinds = models.CharField('类型', max_length=20)
    status = models.IntegerField('状态', choices=STATUS, default=1)
    remark = models.TextField('备注', null=True, blank=True)
    updated = models.DateField('更新时间', auto_now=True)
    created = models.DateField('创建时间', auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '产品列表'
        verbose_name_plural = '产品列表'
