import json
import time
from kafka import KafkaProducer
# 实例化KafkaProducer，实现Kafka的连接
# bootstrap_servers是Kafka的连接信息
producer = KafkaProducer(bootstrap_servers=["127.0.0.1:9092"])
# 设置Kafka的主题
topic = "A1"
for i in range(20):
    d = {"id": str(int(time.time()*1000)+i)}
    # 将字典转换为JSON格式，然后再转换为字节格式
    data = json.dumps(d, ensure_ascii=True).encode("utf-8")
    # 往主题A1发送数据
    # 参数topic是必选参数，代表主题名称
    # 参数value是必选参数，代表需要发送的数据
    # 参数partition是可选参数，代表主题里面的分区，默认为0
    producer.send(topic=topic, value=data, partition=0)
    print(d)
# 关闭Kafka连接
producer.close()
