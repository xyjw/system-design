from kafka import KafkaConsumer
import json

consumer = KafkaConsumer("A1", bootstrap_servers=["127.0.0.1:9092"])
for i in consumer:
    # 输出Kafka数据
    print(i)
    # 输出生产者发送的数据
    print(json.loads(i.value))

# 数据断点消费必须设置参数group_id
# 参数group_id是设置用户组
consumer = KafkaConsumer("A1", bootstrap_servers=["127.0.0.1:9092"], group_id='AA')
for i in consumer:
    # 输出Kafka数据
    print(i)
    # 输出生产者发送的数据
    print(json.loads(i.value))
