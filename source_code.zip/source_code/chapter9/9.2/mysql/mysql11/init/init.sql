alter user 'root'@'%' identified with mysql_native_password by 'QAZwsx1234!';
CHANGE MASTER TO 
MASTER_HOST = '159.75.213.241',
MASTER_PORT = 3306,
MASTER_USER = 'root',
MASTER_PASSWORD = 'QAZwsx1234!';
START SLAVE;