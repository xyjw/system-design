from django.db import models
from django.db import connection
from django.db.backends.base.schema import BaseDatabaseSchemaEditor

STATUS = (
    (0, 0),
    (1, 1)
)

class Product(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField('名称', max_length=50)
    quantity = models.IntegerField('数量', default=1)
    kinds = models.CharField('类型', max_length=20)
    status = models.IntegerField('状态', choices=STATUS, default=1)
    remark = models.TextField('备注', null=True, blank=True)
    updated = models.DateField('更新时间', auto_now=True)
    created = models.DateField('创建时间', auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        app_label = 'index'
        verbose_name = '产品列表'
        verbose_name_plural = '产品列表'
        db_table = 'index_product'

def create_table(sql):
    # 创建数据表必须使用try……except，因为数据表已存在的时候会提示异常
    try:
        with BaseDatabaseSchemaEditor(connection) as editor:
            editor.execute(sql=sql)
    except:
        pass

# 创建分表
tb_list = []
for i in range(3):
    create_table(f'''
        create table  if not exists index_product{i}(
            `id` int NOT NULL,
            `name` varchar(50) NOT NULL,
            `quantity` int NOT NULL,
            `kinds` varchar(20) NOT NULL,
            `status` int NOT NULL,
            `remark` longtext,
            `updated` date NOT NULL,
            `created` date NOT NULL,
            PRIMARY KEY (`id`)
        )ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ''')
    tb_list.append(f'index_product{i}')

# 创建总表
# tb_str是将所有分表联合到总表
tb_str = ','.join(tb_list)
create_table(f'''
    create table  if not exists index_product(
        `id` int NOT NULL,
        `name` varchar(50) NOT NULL,
        `quantity` int NOT NULL,
        `kinds` varchar(20) NOT NULL,
        `status` int NOT NULL,
        `remark` longtext,
        `updated` date NOT NULL,
        `created` date NOT NULL,
        PRIMARY KEY (`id`)
    )ENGINE=MERGE UNION=({tb_str}) INSERT_METHOD=LAST 
    CHARSET=utf8;
''')
