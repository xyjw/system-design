import random
import time

from django.http import JsonResponse
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
def loginView(request):
    res = {'result': False}
    if request.method == 'POST':
        u = request.POST.get('username', '')
        p = request.POST.get('password', '')
        if User.objects.filter(username=u):
            user = authenticate(username=u, password=p)
            if user:
                if user.is_active:
                    login(request, user)
                    res['result'] = True
    return JsonResponse(res)


@csrf_exempt
def productView(request):
    '''
    GET请求是获取数据
    POST请求是新增或修改数据
    :param request:
    :return:
    '''
    if request.method == 'GET':
        q = request.GET.get('q', '')
        data = Product.objects.filter(status=1)
        if q:
            data = Product.objects.filter(name__icontains=q)
        result = []
        for i in data.all():
            value = {'name': i.name,
                     'quantity': i.quantity,
                     'kinds': i.kinds}
            result.append(value)
        return JsonResponse(result, safe=False)
    else:
        id = request.POST.get('id', '')
        name = request.POST.get('name', '')
        quantity = request.POST.get('quantity', 1)
        kinds = request.POST.get('kinds', '')
        d = dict(name=name, quantity=quantity, kinds=kinds)
        p = Product.objects
        # id不存在就在分表中随机抽取写入数据
        if not id:
            d['id'] = int(time.time())
            # 更换数据表写入数据
            tbs = ['index_product0', 'index_product1', 'index_product2']
            tb = random.choice(tbs)
            print(tb)
            p.model._meta.db_table = tb
            p.create(**d)
        else:
            # id存在就在总表中查询并修改数据
            p.filter(id=id).update(**d)
        return JsonResponse({'result': True}, safe=False)
