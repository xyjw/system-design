import time
from django.http import JsonResponse
from .models import *
from django.forms.models import model_to_dict
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def loginView(request):
    res = {'result': False}
    if request.method == 'POST':
        u = request.POST.get('username', '')
        p = request.POST.get('password', '')
        if User.objects.filter(username=u):
            user = authenticate(username=u, password=p)
            if user:
                if user.is_active:
                    login(request, user)
                    res['result'] = True
    return JsonResponse(res)


def productView(request):
    if request.method == 'GET':
        q = request.GET.get('q', '')
        if q:
            data = Product.objects.filter(name__icontains=q)
        else:
            # using可以自行选择数据库执行数据操作
            data = Product.objects.using('default').filter(status=1)
        result = []
        for i in data.all():
            value = {'name': i.name,
                     'quantity': i.quantity,
                     'kinds': i.kinds}
            result.append(value)
        return JsonResponse(result, safe=False)
