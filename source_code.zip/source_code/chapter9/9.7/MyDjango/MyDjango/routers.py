from django.conf import settings

# 导入自定义属性DATABASE_APPS_MAPPING
DATABASE_MAPPING = settings.DATABASE_APPS_MAPPING

class Router:
    '''
    数据库分库功能
    '''

    def db_for_read(self, model, **hints):
        '''
        读数据库
        :param model:
        :param hints:
        :return:
        '''
        if model._meta.app_label in DATABASE_MAPPING.keys():
            return DATABASE_MAPPING[model._meta.app_label]
        return None

    def db_for_write(self, model, **hints):
        '''
        写数据库
        :param model:
        :param hints:
        :return:
        '''
        if model._meta.app_label in DATABASE_MAPPING.keys():
            return DATABASE_MAPPING[model._meta.app_label]
        return None

    def allow_relation(self, obj1, obj2, **hints):
        '''
        是否运行关联操作
        :param obj1:
        :param obj2:
        :param hints:
        :return:
        '''
        db_obj1 = DATABASE_MAPPING.get(obj1._meta.app_label)
        db_obj2 = DATABASE_MAPPING.get(obj2._meta.app_label)
        if db_obj1 and db_obj2:
            if db_obj1 == db_obj2:
                return True
            else:
                return False
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        '''
        是否允许执行数据迁移
        :param obj1:
        :param obj2:
        :param hints:
        :return:
        '''
        if db in DATABASE_MAPPING.values():
            return DATABASE_MAPPING.get(app_label) == db
        elif app_label in DATABASE_MAPPING.keys():
            return False
        return None
