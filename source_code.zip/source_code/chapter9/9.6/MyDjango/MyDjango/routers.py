import random
class Router:
    '''
    数据库主从读写分离
    '''
    def db_for_read(self, model, **hints):
        '''
        读数据库
        使用random.choices在多个从库随机选一个
        还可以编写负载均衡策略
        :param model:
        :param hints:
        :return:
        '''
        return random.choice(['slave1', 'slave2'])

    def db_for_write(self, model, **hints):
        '''
        写数据库
        如果有多个主库，可以使用random.choices随机选取
        还可以编写负载均衡策略
        :param model:
        :param hints:
        :return:
        '''
        return 'default'

    def allow_relation(self, obj1, obj2, **hints):
        '''
        是否运行关联操作
        :param obj1:
        :param obj2:
        :param hints:
        :return:
        '''
        return True

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        '''
        是否允许执行数据迁移
        :param obj1:
        :param obj2:
        :param hints:
        :return:
        '''
        return True
