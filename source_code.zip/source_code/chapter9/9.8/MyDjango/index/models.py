from django.db import models
from django.conf import settings

STATUS = (
    (0, 0),
    (1, 1)
)


class Product(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField('名称', max_length=50)
    quantity = models.IntegerField('数量', default=1)
    kinds = models.CharField('类型', max_length=20)
    status = models.IntegerField('状态', choices=STATUS, default=1)
    remark = models.TextField('备注', null=True, blank=True)
    updated = models.DateField('更新时间', auto_now=True)
    created = models.DateField('创建时间', auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        app_label = 'index'
        verbose_name = '产品列表'
        verbose_name_plural = '产品列表'


def createModel(name, fields, app_label, options=None):
    """
    动态定义模型对象
    :param name: 模型的命名
    :param fields: 模型字段
    :param app_label: 模型所属的项目应用
    :param options: 模型Meta类的属性设置
    :return: 返回模型对象
    """
    class Meta:
        pass
    setattr(Meta, 'app_label', app_label)
    # 设置模型Meta类的属性
    if options is not None:
        for key, value in options.items():
            setattr(Meta, key, value)
    # 添加模型属性和模型字段
    attrs = {'__module__': f'{app_label}.models', 'Meta': Meta}
    attrs.update(fields)
    # 使用type动态创建类
    return type(name, (models.Model,), attrs)


def createDb(model):
    """
    使用ORM的数据迁移创建数据表
    :param model: 模型对象
    """
    from django.utils.connection import ConnectionProxy
    from django.db.utils import ConnectionHandler
    from django.db.backends.base.schema import BaseDatabaseSchemaEditor
    # 创建数据表必须使用try……except，因为数据表已存在的时候会提示异常
    try:
        db = settings.DATABASE_APPS_MAPPING[model._meta.app_label]
        connect = ConnectionProxy(ConnectionHandler(), db)
        with BaseDatabaseSchemaEditor(connect) as editor:
            editor.create_model(model=model)
    except:
        pass


def createTable(model_name, app_label):
    """
    定义模型对象和创建相应数据表
    :param model_name: 模型名称（数据表名称）
    :param app_label: 代表模型定义在那个项目应用
    :return: 返回模型对象，便于视图执行增删改查
    """
    fields = {
        'id': models.AutoField(primary_key=True),
        'product': models.CharField(max_length=20),
        'sales': models.IntegerField(),
        '__str__': lambda self: str(self.id), }
    options = {
        'verbose_name': model_name,
        'db_table': model_name,
    }
    m = createModel(name=model_name, fields=fields,
                    app_label=app_label, options=options)
    createDb(m)
    return m
