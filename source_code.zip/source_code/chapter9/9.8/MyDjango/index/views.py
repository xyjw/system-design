import time
from django.http import JsonResponse
from .models import *
from django.forms.models import model_to_dict
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def loginView(request):
    '''
    用户登录接口
    :param request:
    :return:
    '''
    res = {'result': False}
    if request.method == 'POST':
        u = request.POST.get('username', '')
        p = request.POST.get('password', '')
        if User.objects.filter(username=u):
            user = authenticate(username=u, password=p)
            if user:
                if user.is_active:
                    login(request, user)
                    res['result'] = True
    return JsonResponse(res)


def productView(request):
    '''
    产品查询接口
    :param request:
    :return:
    '''
    if request.method == 'GET':
        q = request.GET.get('q', '')
        if q:
            data = Product.objects.filter(name__icontains=q)
        else:
            # using可以自行选择数据库执行数据操作
            data = Product.objects.using('default').filter(status=1)
        result = []
        for i in data.all():
            value = {'name': i.name,
                     'quantity': i.quantity,
                     'kinds': i.kinds}
            result.append(value)
        return JsonResponse(result, safe=False)

@csrf_exempt
def salesView(request):
    '''
    自动创建每天销量表
    GET请求是查询数据
    POST请求是新增或修改数据
    :param request:
    :return:
    '''
    data = {'result': True, 'data': []}
    today = time.localtime(time.time())
    date = f"sales{time.strftime('%Y%m%d', today)}"
    if request.method == 'GET':
        q = request.GET.get('q', '')
        # 请求参数date非空，查询某一天的数据表的数据
        date = request.GET.get('date', '')
        # 请求参数date为空，则默认查询当天
        date = f"sales{date}" if date else f"sales{time.strftime('%Y%m%d', today)}"
        model_name = createTable(date, 'index')
        d = model_name.objects.all()
        if q:
            d = d.filter(product__icontains=q)
        for i in d:
            data['data'].append(model_to_dict(i))
    else:
        model_name = createTable(date, 'index')
        product = request.POST.get('product', '')
        sales = request.POST.get('sales', 1)
        if product:
            # 参数product存在数据表则执行更新处理，反之执行新增
            model_name.objects.update_or_create(
                defaults=dict(product=product, sales=int(sales)),
                **{'product': product}
            )
    return JsonResponse(data, safe=False)
