from .consulclient import ConsulClient

class HttpServer():
    '''定义服务注册与发现，将Django服务注册到Consul中'''
    def __init__(self, host, port, consulhost, consulport):
        self.port = port
        self.host = host
        self.appname = ['index', 'user']
        self.consulhost = consulhost
        self.consulport = consulport

    def startServer(self):
        client = ConsulClient(host=self.consulhost, port=self.consulport)
        # 注册服务，将路由index和user依次注册
        for aps in self.appname:
            service_id = aps + self.host + ':' + str(self.port)
            url = f'http://{self.host}:{str(self.port)}/check'
            client.register(aps,
                            service_id=service_id,
                            address=self.host,
                            port=self.port,
                            tags=['master'],
                            interval='30s',
                            url=url)
