import os
from django.core.wsgi import get_wsgi_application
from microservice.startServer import HttpServer
# 实现Django与Consul数据通信
server = HttpServer('127.0.0.1', 8000, '127.0.0.1', 8500)
server.startServer()
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'MyDjango.settings')
application = get_wsgi_application()
