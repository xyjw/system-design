
from django.urls import path
from .views import *
urlpatterns = [
    path('', loginView, name='login'),
    path('product.html', productView, name='product'),
]
