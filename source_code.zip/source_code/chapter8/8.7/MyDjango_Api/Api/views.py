from django.http import JsonResponse
import requests

def loginView(request):
    result = {'result': False}
    if request.method == 'POST':
        url = f'http://127.0.0.1:8081/'
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        data = {'username': username, 'password': password}
        user = requests.post(url, data=data)
        result = user.json()
    return JsonResponse(result, safe=False)

def productView(request):
    result = []
    if request.method == 'GET':
        q = request.GET.get('q', '')
        url = f'http://127.0.0.1:8082/product.html?q={q}'
        products = requests.get(url)
        result = products.json()
    return JsonResponse(result, safe=False)
