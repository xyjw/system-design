from django.http import JsonResponse
from .models import Product

def productView(request):
    if request.method == 'GET':
        q = request.GET.get('q', '')
        data = Product.objects.filter(status=1)
        if q:
            data = Product.objects.filter(name__icontains=q)
        result = []
        for i in data.all():
            value = {'name': i.name,
                     'quantity': i.quantity,
                     'kinds': i.kinds}
            result.append(value)
        return JsonResponse(result, safe=False)
